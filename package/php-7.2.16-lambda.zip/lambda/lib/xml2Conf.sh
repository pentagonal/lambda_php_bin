#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/opt/lambda/lib"
XML2_LIBS="-lxml2 -L/opt/lambda/lib -lz -llzma     -licui18n -licuuc -licudata   -lm "
XML2_INCLUDEDIR="-I/opt/lambda/include/libxml2"
MODULE_VERSION="xml2-2.9.9"

